
estimation
===========

.. contents::
    :local:
    :backlinks: top


.. automodule:: estimation

Ce module contient différentes fonctions pour estimer les paramètres de végétation. Dans de nombreux cas, le principe des estimateurs (fonctions prefixées par *estim*) minimisent un critère
donné par les fonctions detaillées dans la partie critère.

Les critères
+++++++++++++

Afin d'être utilisés par le module :mod:`numpy.optimize` les fonctions correspondant à des critères
à optimiser sont toutes structurées de la manière suivante :

    * *f(X,*arg)*
        * *X* : vecteur (*array* à une dimension). quantité à optimiser
        * *arg* : tuple. arguments supplémentaires nécessaires au calcul de la fonction

*Exemple*:

>>> import load_param as lp
>>> import numpy as np
>>> param=lp.load_param('DB_1');param.z_g=0
>>> Ups=param.get_upsilon_gt()
>>> theta=np.array([33,0.0345,0.7,0.8,0.8])
>>> Crit=e.mlogV_Tg_Tv_known(theta_vrai+eps,
>>>                          Ups,param.get_kzlist(),np.cos(param.theta),
>>>                          param.Na,param.T_vol,param.T_ground,
>>>                          param.N,param.z_g)
>>> print Crit
42
              
.. autosummary::
    :toctree: generated/

    ~estimation.J
    ~estimation.J2
    ~estimation.J_tot
    ~estimation.J_scal
    ~estimation.V_scal
    ~estimation.V_scal_gt_inconnu
    ~estimation.mlogV_zg_known
    ~estimation.mlogV_zg_known_noconstraint
    ~estimation.mlogV
    ~estimation.mlogV_Tg_Tv_zg_known
    ~estimation.mlogV_Tg_Tv_zg_sigv_known
    ~estimation.mlogV_gt_inconnu_all
    ~estimation.mlogV_hv_sig_gt_Tg_zg_known
    ~estimation.mlogV_hv_sig_gt_Tv_zg_known
    ~estimation.mlogV_hv_sig_gt_Tv_Tg_zg_known
    ~estimation.crit_ang
    ~estimation.crit_ang2

Les estimateurs 
++++++++++++++++

.. autosummary::
    :toctree: generated/

    ~estimation.estim_rvog_crit_divers
    ~estimation.estim_rvog_b_free
    ~estimation.estim_dpct_kz
    ~estimation.estim_ecart_ang
    ~estimation.estim_ecart_ang_opt
    ~estimation.estim_ecart_ang_opt2
    ~estimation.estim_ecart_ang_reestim_b
    ~estimation.estim_ecart_ang_tot
    ~estimation.estim_ecart_ang_scal
    ~estimation.estim_V_scal
    ~estimation.estim_mlogV_zg_known
    ~estimation.estim_mlogV_gt_inconnu_all
    ~estimation.estim_V_scal_gt_inconnu
    ~estimation.estim_mlogV_Tg_Tv_zg_known

Autres fonctions
+++++++++++++++++

.. autosummary::
    :toctree: generated/

    ~estimation.I1
    ~estimation.I2
    ~estimation.gammav
    ~estimation.gammavgt
    ~estimation.EQM
    ~estimation.ressemblance
    ~estimation.vraissemb
    ~estimation.Ups_reconstr
    ~estimation.Ups_reconstr2
    ~estimation.load_nv_phiv





