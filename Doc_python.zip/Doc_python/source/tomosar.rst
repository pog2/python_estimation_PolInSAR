
tomosar
========

.. contents::
    :local:
    :backlinks: top

Ce module contient la classe :class:`tomosar.TomoSARDataSet` permettant de gerer les données
Multi-baseline SAR ainsi que des routines destinées au traitement 
tomographique proposé par S.Tebaldini (methode SKP).

Classe TomoSARData_Set
+++++++++++++++++++++++

Cette classe permet de gerer les données multi-baseline.   

.. autoclass:: tomosar.TomoSARDataSet
    :members:    

Fonctions de tomosar
+++++++++++++++++++++

.. automodule:: tomosar
    :members:
