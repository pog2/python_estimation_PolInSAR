*******
Annexe
*******


.. _vecto:

================================
Vectorisation des matrices T
================================

Lorsque q'une fonction critère du module :mod:`estimation` prend une matrice T en inconnue, celle ci est stockée sous forme d'un vecteur de taille 9 
(T est supposée hermitienne) de la façon suivante :

.. math:: 
    :nowrap:

    T = 
    \begin{bmatrix}
    t_1 & t_4 + jt_5 & t_6+jt_7 \\
    t_4-jt_5 & t_2 & t_8+jt_9 \\
    t_6-jt_7 & t_8-jt_9 & t_3 \\
    \end{bmatrix}
     
    -->    
    vecT = (t_1,t_2,t_3,t_4,t_5,t_6,t_7,t_8,t_9)

     

