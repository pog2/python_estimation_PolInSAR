plot_tomo.plot_moy
==================

.. currentmodule:: plot_tomo

.. autofunction:: plot_moy