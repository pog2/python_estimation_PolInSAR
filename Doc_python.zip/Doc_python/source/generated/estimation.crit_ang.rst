estimation.crit_ang
===================

.. currentmodule:: estimation

.. autofunction:: crit_ang