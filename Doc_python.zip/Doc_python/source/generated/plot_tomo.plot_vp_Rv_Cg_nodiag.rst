plot_tomo.plot_vp_Rv_Cg_nodiag
==============================

.. currentmodule:: plot_tomo

.. autofunction:: plot_vp_Rv_Cg_nodiag