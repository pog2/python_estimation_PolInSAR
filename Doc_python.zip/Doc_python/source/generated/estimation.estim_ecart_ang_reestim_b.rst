estimation.estim_ecart_ang_reestim_b
====================================

.. currentmodule:: estimation

.. autofunction:: estim_ecart_ang_reestim_b