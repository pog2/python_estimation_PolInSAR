plot_tomo.plot_vp
=================

.. currentmodule:: plot_tomo

.. autofunction:: plot_vp