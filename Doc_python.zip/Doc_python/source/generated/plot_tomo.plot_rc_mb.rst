plot_tomo.plot_rc_mb
====================

.. currentmodule:: plot_tomo

.. autofunction:: plot_rc_mb