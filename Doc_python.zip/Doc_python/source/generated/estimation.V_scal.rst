estimation.V_scal
=================

.. currentmodule:: estimation

.. autofunction:: V_scal