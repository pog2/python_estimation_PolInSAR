estimation.gammavgt
===================

.. currentmodule:: estimation

.. autofunction:: gammavgt