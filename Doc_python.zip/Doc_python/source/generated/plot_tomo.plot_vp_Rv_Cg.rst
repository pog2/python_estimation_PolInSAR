plot_tomo.plot_vp_Rv_Cg
=======================

.. currentmodule:: plot_tomo

.. autofunction:: plot_vp_Rv_Cg