plot_tomo.plot_cu_sm_possible
=============================

.. currentmodule:: plot_tomo

.. autofunction:: plot_cu_sm_possible