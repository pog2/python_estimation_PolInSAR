estimation.J2
=============

.. currentmodule:: estimation

.. autofunction:: J2