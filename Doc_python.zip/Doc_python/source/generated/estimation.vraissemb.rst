estimation.vraissemb
====================

.. currentmodule:: estimation

.. autofunction:: vraissemb