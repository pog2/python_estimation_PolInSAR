estimation.estim_mlogV_Tg_Tv_zg_known
=====================================

.. currentmodule:: estimation

.. autofunction:: estim_mlogV_Tg_Tv_zg_known