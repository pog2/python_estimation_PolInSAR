RVoG_MB
=======

.. automodule:: RVoG_MB

   
   
   .. rubric:: Functions

   .. autosummary::
   
      Tv_Tg_from_A_E_X
      bcr_hv_mb
      bcr_hv_mb_Tv_Tg_sigv_gt_known
      bcr_hv_mb_Tv_Tg_zg_connu
      bcr_hv_mb_sigv_connu
      bcr_hv_mb_sigv_inconnu
      bcr_hv_mb_zg_connu
      bcr_mb_A_influence
      bcr_mb_N_influence
      bcr_mb_kz_influence
      gamma_v_kz
      get_Na_from_Nb
      get_Nb_from_Na
      get_Tm_from_vecTm
      get_idx_dble_from_idx_mono
      get_vecTm_from_Tm
      plot_and_save_bcr_mb_A_E_influence
      plot_and_save_bcr_mb_N_influence
      plot_and_save_bcr_mb_kz_influence_A_E_variable
      plot_bcr_mb_kz_influence
      plot_rvog_bcr_h_v
      plot_rvog_bcr_sigma_v
      plot_rvog_bcr_sigma_v_hsig
      rvog_bcr_h_v
      rvog_bcr_sigma_v
      rvog_reduction
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      param_rvog
   
   

   
   
   