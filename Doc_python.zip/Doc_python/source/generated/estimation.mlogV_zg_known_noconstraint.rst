estimation.mlogV_zg_known_noconstraint
======================================

.. currentmodule:: estimation

.. autofunction:: mlogV_zg_known_noconstraint