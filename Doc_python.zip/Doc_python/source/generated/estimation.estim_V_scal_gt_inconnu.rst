estimation.estim_V_scal_gt_inconnu
==================================

.. currentmodule:: estimation

.. autofunction:: estim_V_scal_gt_inconnu