plot_tomo.pplot
===============

.. currentmodule:: plot_tomo

.. autofunction:: pplot