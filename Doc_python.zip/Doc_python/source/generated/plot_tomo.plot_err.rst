plot_tomo.plot_err
==================

.. currentmodule:: plot_tomo

.. autofunction:: plot_err