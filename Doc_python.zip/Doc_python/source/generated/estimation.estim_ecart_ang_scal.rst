estimation.estim_ecart_ang_scal
===============================

.. currentmodule:: estimation

.. autofunction:: estim_ecart_ang_scal