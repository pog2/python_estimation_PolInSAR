estimation.J_scal
=================

.. currentmodule:: estimation

.. autofunction:: J_scal