plot_tomo.plot_gammav_from_kz
=============================

.. currentmodule:: plot_tomo

.. autofunction:: plot_gammav_from_kz