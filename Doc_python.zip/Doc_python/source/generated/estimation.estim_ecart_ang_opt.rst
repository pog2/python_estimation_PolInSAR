estimation.estim_ecart_ang_opt
==============================

.. currentmodule:: estimation

.. autofunction:: estim_ecart_ang_opt