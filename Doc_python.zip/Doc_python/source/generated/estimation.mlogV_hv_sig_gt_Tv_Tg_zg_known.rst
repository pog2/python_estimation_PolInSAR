estimation.mlogV_hv_sig_gt_Tv_Tg_zg_known
=========================================

.. currentmodule:: estimation

.. autofunction:: mlogV_hv_sig_gt_Tv_Tg_zg_known