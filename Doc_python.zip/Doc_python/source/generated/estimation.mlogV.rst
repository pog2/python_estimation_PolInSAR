estimation.mlogV
================

.. currentmodule:: estimation

.. autofunction:: mlogV