plot_tomo.plot_mod_gamma_v
==========================

.. currentmodule:: plot_tomo

.. autofunction:: plot_mod_gamma_v