estimation.ressemblance
=======================

.. currentmodule:: estimation

.. autofunction:: ressemblance