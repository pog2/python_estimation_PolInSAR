estimation.estim_ecart_ang_opt2
===============================

.. currentmodule:: estimation

.. autofunction:: estim_ecart_ang_opt2