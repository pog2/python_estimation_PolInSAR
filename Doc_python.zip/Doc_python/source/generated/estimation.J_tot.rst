estimation.J_tot
================

.. currentmodule:: estimation

.. autofunction:: J_tot