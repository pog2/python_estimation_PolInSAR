estimation.estim_ecart_ang_tot
==============================

.. currentmodule:: estimation

.. autofunction:: estim_ecart_ang_tot