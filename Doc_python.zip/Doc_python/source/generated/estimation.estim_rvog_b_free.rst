estimation.estim_rvog_b_free
============================

.. currentmodule:: estimation

.. autofunction:: estim_rvog_b_free