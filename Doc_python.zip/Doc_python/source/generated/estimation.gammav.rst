estimation.gammav
=================

.. currentmodule:: estimation

.. autofunction:: gammav