estimation.mlogV_zg_known
=========================

.. currentmodule:: estimation

.. autofunction:: mlogV_zg_known