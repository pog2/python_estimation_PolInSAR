estimation.V_scal_gt_inconnu
============================

.. currentmodule:: estimation

.. autofunction:: V_scal_gt_inconnu