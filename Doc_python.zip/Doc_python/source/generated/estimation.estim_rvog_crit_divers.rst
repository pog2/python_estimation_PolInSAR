estimation.estim_rvog_crit_divers
=================================

.. currentmodule:: estimation

.. autofunction:: estim_rvog_crit_divers