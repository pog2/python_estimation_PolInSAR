estimation.I1
=============

.. currentmodule:: estimation

.. autofunction:: I1