plot_tomo.plot_converg
======================

.. currentmodule:: plot_tomo

.. autofunction:: plot_converg