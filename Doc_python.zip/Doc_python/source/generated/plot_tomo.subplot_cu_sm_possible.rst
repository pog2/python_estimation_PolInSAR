plot_tomo.subplot_cu_sm_possible
================================

.. currentmodule:: plot_tomo

.. autofunction:: subplot_cu_sm_possible