estimation.I2
=============

.. currentmodule:: estimation

.. autofunction:: I2