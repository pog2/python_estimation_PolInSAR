estimation.estim_mlogV_zg_known
===============================

.. currentmodule:: estimation

.. autofunction:: estim_mlogV_zg_known