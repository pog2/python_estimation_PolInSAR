estimation.crit_ang2
====================

.. currentmodule:: estimation

.. autofunction:: crit_ang2