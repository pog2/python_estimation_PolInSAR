estimation.EQM
==============

.. currentmodule:: estimation

.. autofunction:: EQM