estimation.estim_V_scal
=======================

.. currentmodule:: estimation

.. autofunction:: estim_V_scal