plot_tomo.plot_gammav
=====================

.. currentmodule:: plot_tomo

.. autofunction:: plot_gammav