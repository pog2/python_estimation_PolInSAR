estimation.J
============

.. currentmodule:: estimation

.. autofunction:: J