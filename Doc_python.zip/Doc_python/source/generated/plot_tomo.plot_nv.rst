plot_tomo.plot_nv
=================

.. currentmodule:: plot_tomo

.. autofunction:: plot_nv