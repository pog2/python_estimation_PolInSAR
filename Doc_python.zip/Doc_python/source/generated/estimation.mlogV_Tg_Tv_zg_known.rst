estimation.mlogV_Tg_Tv_zg_known
===============================

.. currentmodule:: estimation

.. autofunction:: mlogV_Tg_Tv_zg_known