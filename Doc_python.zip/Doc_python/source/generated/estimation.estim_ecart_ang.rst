estimation.estim_ecart_ang
==========================

.. currentmodule:: estimation

.. autofunction:: estim_ecart_ang