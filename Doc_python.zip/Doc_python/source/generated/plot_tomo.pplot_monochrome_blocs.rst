plot_tomo.pplot_monochrome_blocs
================================

.. currentmodule:: plot_tomo

.. autofunction:: pplot_monochrome_blocs