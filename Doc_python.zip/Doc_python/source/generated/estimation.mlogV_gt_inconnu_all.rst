estimation.mlogV_gt_inconnu_all
===============================

.. currentmodule:: estimation

.. autofunction:: mlogV_gt_inconnu_all