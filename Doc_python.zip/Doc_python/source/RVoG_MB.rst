RVoG_MB
===========

.. contents::
    :local:
    :backlinks: top

Ce module contient la classe :class:`param_rvog`, permettant de definir un jeu de paramètres RVoG,
ainsi que des fonctions associées.

Classe param_rvog
++++++++++++++++++

Un object de type *param_rvog* définit un jeu de paramètres RVoG. L'initialisation se fait comme suit 

>>> import RVoG_MB
>>> N = 100 #Taille de l'echantillon
>>> k_z = [0.1,0.15] #Liste contenant les kz1j (kz12,kz13 en dual-baseline)
>>> T_vol = np.eye(3) #Réponse polar. du volume (array 3x3)
>>> T_ground = np.diag([44,16,11]) #Réponse polar du sol (array 3x3)
>>> theta=45*np.pi/180 #Angle d'incidence
>>> gammat=np.ones((3,3))#Matrice symetrique contenant les décoherences temporelle (unité sur la diagonale)
>>> sigma_v=0.0345 #Attenuation dans le volume
>>> h_v=30 #Hauteur de végétation
>>> z_g = 4 #Altitude du sol
>>> param = param_rvog(N=N,k_z=k_z,theta=theta,T_vol=T_vol,
>>>                    T_ground=T_ground,h_v=h_v,z_g=z_g,
>>>                    sigma_v=sigma_v,mat_gamma_t=gammat)

On peut également initialiser à l'aide de la classe :class:`load_param` où sont stockés quelques 
configurations.

>>> import RVoG_MB
>>> import load_param
>>> param = load_param('DB_0')

.. autoclass:: RVoG_MB.param_rvog
    :members:


Fonctions de RVoG_MB
++++++++++++++++++++++

.. automodule:: RVoG_MB
    :members:






