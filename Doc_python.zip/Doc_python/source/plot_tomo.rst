plot_tomo
=========

.. automodule:: plot_tomo

Ce module contient des fonctions destinées à tracer et representer des données. 

.. contents::
    :local:
    :backlinks: top


Fonctions principales
++++++++++++++++++++++

.. autosummary::
    :toctree: generated/

     ~plot_tomo.plot_converg
     ~plot_tomo.plot_err
     ~plot_tomo.pplot
     ~plot_tomo.plot_cu_sm_possible
     ~plot_tomo.plot_rc_mb


Fonctions secondaires
++++++++++++++++++++++

Fonctions très spécifiques dont l'usage sera certainement faible.

.. autosummary::
    :toctree: generated/

    ~plot_tomo.pplot_monochrome_blocs    
    ~plot_tomo.plot_gammav    
    ~plot_tomo.plot_gammav_from_kz    
    ~plot_tomo.plot_mod_gamma_v    
    ~plot_tomo.plot_moy    
    ~plot_tomo.plot_nv    
    ~plot_tomo.plot_phiv
    ~plot_tomo.plot_vp    
    ~plot_tomo.plot_vp_Rv_Cg    
    ~plot_tomo.plot_vp_Rv_Cg_nodiag    
    ~plot_tomo.subplot_cu_sm_possible
