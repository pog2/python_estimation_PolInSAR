
tomosar_synth
==============

.. contents::
    :local:
    :backlinks: top

Ce module contient la classe :class:`tomosar_synth.TomoSARDataSet_synth` necessaire à la génération des données synthétiques 
Multi-baseline SAR ai	nsi que des routines destinées au traitement 
tomographique proposé par S.Tebaldini (methode SKP).

Classe TomoSARData_Set_synth
++++++++++++++++++++++++++++++

Cette classe permet de générer et gerer les données multi-baseline. 
Les données sont initialisées à l'aide d'un object de la classe
:class: *param_rvog* 


L'initialisation peut se faire à l'aide des jeux de paramètres définis dans :mod:`load_param` comme suit : 

>>> import RVoG_MB
>>> import tomosar_synth_v5
>>> import load_param 
>>> param = load_param('DB_0')
>>> data = TomoSARDataSet_synth(param)

Pour générer la matrice de covariance correspondant au données on applique
la commande

>>> Wnoise = data.get_W_k_rect(param,param.N)

Un exemple classique d'utilisation est le suivant : 

>>> import tomosar_synth_v5
>>> import load_param
>>> param = load_param('DB_0')
>>> data = TomoSARDataSet_synth(param)
>>> N=10**6
>>> #Matrice de covariance bruitée
>>> Wnoise = data.get_W_k_rect(param,N)
>>> #Normalisation 
>>> W_norm,_ = tom.normalize_MPMB_PS_Tebald(Wnoise,param.Na)
>>> 
>>> bvrai=tom.b_true_from_param(param)
>>> hv,sigv,vec_gt,bopt = e.estim_ecart_ang_scal(W,param,
>>>                                              critere='J2',
>>>                                              zg_connu=param.z_g,
>>>                                              U0=np.array([param.h_v,param.sigma_v]),
>>>                                              b0=bvrai)
    

.. autoclass:: tomosar_synth.TomoSARDataSet_synth
    :members:   

Fonctions tomosar_synth
+++++++++++++++++++++++++

.. automodule:: tomosar_synth
	:members:


