
optimisation
=============

.. automodule:: optimisation
   :members:
